// Initialize Lucide icons
lucide.createIcons();

console.log("Script loaded successfully!");
